$(function(){
	$(".add_img").click(function(){
		alert("1000점이 적립되었습니다.");
		location.href = "https://www.koreaisacademy.com/";
	});
});