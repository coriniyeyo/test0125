$(function(){
	$("#btn").click(function(){
		location.href = "Controller?command=Membership_form";
	});
});